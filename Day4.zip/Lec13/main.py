class Horse:
    """
    Лошадь(конь) - класс родитель
    """
    hooves = 3 # копыта
    tail =  True 
    weight = -50
    body = True 
    love_grass = True 


class Unicorn:
    """
    Наш шедевр. Мы хотим его создать по образу и подобию Horse
    """
    hooves = 3 # копыта
    tail =  True 
    weight = -50
    body = True 
    love_grass = True 
    has_horn = True 


class PegasusWithHorn:
    """
    """
    hooves = 3 # копыта
    tail =  True 
    weight = -50
    body = True 
    love_grass = True 
    has_horn = True 
    can_fly = True 
