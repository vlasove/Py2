from smartphone import SmartPhone

iphone = SmartPhone("IPhone", 1440, 4, 2.8)
print(iphone)
print(dir(iphone))