from main import Sequence

seq = Sequence("popopppopop")