import collections

deque = collections.deque()

print(dir(deque))