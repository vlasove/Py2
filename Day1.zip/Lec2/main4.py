"""
D1: A solution
"""

a_int = int(input())
b_int = int(input())
result = 0

for i in range(a_int , b_int + 1):
    result += i 

print(result)