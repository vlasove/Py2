"""
Функции. (Явные)
"""

def add(a :int = 20, b :int = 30) -> int:
    """
    Эта функция для сложения a и b
    """
    return a + b 


print(add(10, 20))
print(add())
