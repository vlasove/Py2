"""
Хотим создать сервис для потокового воспроизведения фильмов.
Для того, чтобы сохранить фильм, нужно сохранить "критерии фильмовости".


Способ с сохранением фильма в виде набора разреженных переменных - никуда не годится.
"""

title1 = 'HP:1'
duration1 = 210
rating1 = 4.8
actors1 = ['Emma Watson', 'Friend1', 'Rupert Grin']

title2 = 'LOTR:1'
duration2 = 999
rating2 =  4.8
actors2 = ['O Blum', 'Friend1', 'Friend2', 'Fritend3']

title3 = 'HP:2'
duration3 = 220
rating3 = 4.7
actors3 = ['Emma Watson', 'Friend1', 'Rupert Grin']
